<?php

$kon = mysqli_connect("localhost", "root", "", "data");

?>