<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <link rel="stylesheet" href="formcss.css">

        </head>
        <body>
        
        <div class="sidenav">
          <a href="index.html">Homepage</a>
          <a href="tabel.php">Table</a>
        </div>


    <form action="" method="post">
        <label for="name">Nama:</label>
        <input type="text" id="nama" name="nama" required>
        <label for="jurusan">Jurusan:</label>
        <input type="jurusan" id="jurusan" name="jurusan" required>
        <label for="Email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <label for="Jeniskelamin">Jenis kelamin:</label>
        <select id="jeniskelamin" name="jeniskelamin">
            <option value="lakilaki">Laki-laki</option>
            <option value="perempuan">Perempuan</option>
            <option value="lainnya">Lainnya</option>
        </select>
        <label for="Tanggal lahir">Tanggal lahir:</label>
        <input type="date" id="tanggallahir" name="tanggallahir" required>
        <label for="Alamat">Alamat:</label>
        <input type="alamat" id="alamat" name="alamat" required>


        <button type="submit" id="submit" name="submit">Submit</button>
    </form>

    <?php
    include 'kon.php';

    if(isset($_POST['submit'])) 
    {
        $nama=$_POST['nama'];
        $jurusan=$_POST['jurusan'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $jeniskelamin=$_POST['jeniskelamin'];
        $tanggallahir=$_POST['tanggallahir'];
        $alamat=$_POST['alamat'];

        $insertdata=mysqli_query($kon,"insert into data (nama,jurusan,email,password,jeniskelamin,tanggallahir,alamat) VALUES('$nama','$jurusan','$email','$password','$jeniskelamin','$tanggallahir','$alamat')");

    }
?>

</body>

<footer style="text-align: center; position: relative; top: 100px;"
  <p>2023 Febio Website</p>
</footer>

</html>