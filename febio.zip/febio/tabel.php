<?php
include "kon.php";
?>

<!DOCTYPE html>
<html>
    <title>Tabel</title>
    <link rel="stylesheet" href="tabelcss.css">
<head>

</head>
<body>

    <div class="sidenav">
        <a href="index.html">Homepage</a>
        <a href="form.php">Form</a>
      </div>

<h2>Table</h2>

<table>
  <tr>
    <th>nama</th>
    <th>jurusan</th>
    <th>email</th>
    <th>password</th>
    <th>jenis kelamin</th>
    <th>tanggal lahir</th>
    <th>alamat</th>
  </tr>

  <?php  
  $result = mysqli_query($kon,"SELECT * FROM data ORDER BY 'id' ASC");
    while($user_data = mysqli_fetch_array($result)) 
      {         
        echo "<tr>";
        echo "<td>".$user_data['nama']."</td>";
        echo "<td>".$user_data['jurusan']."</td>";
        echo "<td>".$user_data['email']."</td>";  
        echo "<td>".$user_data['password']."</td>";  
        echo "<td>".$user_data['jeniskelamin']."</td>"; 
        echo "<td>".$user_data['tanggallahir']."</td>";
        echo "<td>".$user_data['alamat']."</td>";            
      }
?>
  
</table>

</body>

<footer style="text-align: center; position: fixed; bottom: 10px; left: 45%;"
  <p>2023 Febio Website</p>
</footer>

</html>

